package com.example.oilrpai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import android.view.accessibility.AccessibilityEvent

class OilClickerAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: OilClickerAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Event dipicu dari kontrol overlay / loop analisis layar
    }

    override fun onInterrupt() {
        // Dibersihkan jika service diinterupsi sistem
    }

    fun tapAt(point: PointF, durationMs: Long = 60L) {
        val path = Path().apply {
            moveTo(point.x, point.y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    fun holdAt(point: PointF, holdDurationMs: Long = 600L) {
        val path = Path().apply {
            moveTo(point.x, point.y)
        }
        // GestureDescription menahan sentuhan selama holdDurationMs lalu melepasnya
        val stroke = GestureDescription.StrokeDescription(path, 0L, holdDurationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
}
