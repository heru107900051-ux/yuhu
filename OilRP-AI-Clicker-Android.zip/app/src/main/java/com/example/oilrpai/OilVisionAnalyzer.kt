package com.example.oilrpai

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PointF
import kotlin.math.max
import kotlin.math.min

enum class ArrowDirection {
    UP, DOWN, LEFT, RIGHT
}

sealed class MinigameDecision {
    data object HoldStart : MinigameDecision()
    data object HoldRelease : MinigameDecision()
    data object TapNow : MinigameDecision()
    data class PressArrow(val direction: ArrowDirection) : MinigameDecision()
    data object Idle : MinigameDecision()
}

class OilVisionAnalyzer(
    // Koordinat dinormalisasi (0.0f - 1.0f) agar adaptif terhadap rasio layar
    private val holdButtonPos: PointF = PointF(0.500f, 0.560f),
    private val tapButtonPos: PointF = PointF(0.500f, 0.560f),
    private val arrowButtons: Map<ArrowDirection, PointF> = mapOf(
        ArrowDirection.UP to PointF(0.385f, 0.570f),
        ArrowDirection.DOWN to PointF(0.462f, 0.570f),
        ArrowDirection.LEFT to PointF(0.538f, 0.570f),
        ArrowDirection.RIGHT to PointF(0.615f, 0.570f)
    )
) {

    fun isGreenPixel(color: Int): Boolean {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        val hue = hsv[0]
        val sat = hsv[1]
        val valBright = hsv[2]
        // Rentang HSV hijau terang/neon pada zona hijau bar minigame
        return hue in 110.000f..165.000f && sat >= 0.350f && valBright >= 0.350f
    }

    /**
     * Tahap 1: Memompa Minyak - cek apakah area bar di sekitar indikator sudah masuk zona hijau.
     * Jika sudah menyentuh zona hijau, kembalikan HoldRelease agar tombol dilepas.
     */
    fun analyzeStage1Pump(frame: Bitmap, isHolding: Boolean): MinigameDecision {
        val barTop = (frame.height * 0.440f).toInt()
        val barBottom = (frame.height * 0.500f).toInt()
        val barLeft = (frame.width * 0.360f).toInt()
        val barRight = (frame.width * 0.640f).toInt()

        var greenCount = 0
        for (y in barTop until barBottom step 3) {
            for (x in barLeft until barRight step 3) {
                if (isGreenPixel(frame.getPixel(x, y))) {
                    greenCount++
                }
            }
        }

        // Logika ambang batas: saat indikator/progres memasuki area hijau aktif
        return if (!isHolding) {
            MinigameDecision.HoldStart
        } else if (greenCount > 120) {
            MinigameDecision.HoldRelease
        } else {
            MinigameDecision.Idle
        }
    }

    /**
     * Tahap 2: Menyuling Minyak - deteksi apakah bilah putih vertikal berada di atas zona hijau.
     */
    fun analyzeStage2Refine(frame: Bitmap): MinigameDecision {
        val barTop = (frame.height * 0.440f).toInt()
        val barBottom = (frame.height * 0.500f).toInt()
        val barLeft = (frame.width * 0.360f).toInt()
        val barRight = (frame.width * 0.640f).toInt()

        var brightWhitePixels = 0
        var greenPixels = 0

        for (y in barTop until barBottom step 2) {
            for (x in barLeft until barRight step 2) {
                val px = frame.getPixel(x, y)
                val r = Color.red(px)
                val g = Color.green(px)
                val b = Color.blue(px)

                if (r > 220 && g > 220 && b > 220) {
                    brightWhitePixels++
                }
                if (isGreenPixel(px)) {
                    greenPixels++
                }
            }
        }

        // Trigger tap saat jarum terang dan zona hijau terdeteksi bersamaan dalam jendela aktif
        return if (brightWhitePixels > 25 && greenPixels > 80) {
            MinigameDecision.TapNow
        } else {
            MinigameDecision.Idle
        }
    }

    /**
     * Tahap 3: Mencampur Minyak - mendeteksi panah yang menyala pada baris urutan panah
     * dan memetakkannya ke tombol ATAS / BAWAH / KIRI / KANAN.
     */
    fun analyzeStage3MixArrows(frame: Bitmap): MinigameDecision {
        val seqY = (frame.height * 0.485f).toInt()
        val slotXs = listOf(
            (frame.width * 0.435f).toInt(),
            (frame.width * 0.478f).toInt(),
            (frame.width * 0.521f).toInt(),
            (frame.width * 0.564f).toInt()
        )

        val hsv = FloatArray(3)
        for (slotX in slotXs) {
            if (slotX in 0 until frame.width && seqY in 0 until frame.height) {
                var slotLit = false
                for (dy in -2..2) {
                    for (dx in -2..2) {
                        val sx = min(frame.width - 1, max(0, slotX + dx))
                        val sy = min(frame.height - 1, max(0, seqY + dy))
                        val px = frame.getPixel(sx, sy)
                        Color.colorToHSV(px, hsv)
                        if (hsv[2] > 0.750f || isGreenPixel(px)) {
                            slotLit = true
                            break
                        }
                    }
                    if (slotLit) break
                }

                if (slotLit) {
                    val detectedDir = classifyArrowShape(frame, slotX, seqY)
                    if (detectedDir != null) {
                        return MinigameDecision.PressArrow(detectedDir)
                    }
                }
            }
        }
        return MinigameDecision.Idle
    }

    /**
     * Klasifikasi orientasi panah (UP, DOWN, LEFT, RIGHT) berbasis distribusi massa & lebar sayap panah.
     */
    private fun classifyArrowShape(frame: Bitmap, centerX: Int, centerY: Int): ArrowDirection? {
        val radius = max(8, (frame.width * 0.018f).toInt())
        val hsv = FloatArray(3)

        var topMass = 0
        var bottomMass = 0
        var leftMass = 0
        var rightMass = 0
        var totalBright = 0

        var topSpan = 0
        var bottomSpan = 0
        var leftSpan = 0
        var rightSpan = 0

        for (dy in -radius..radius) {
            val py = centerY + dy
            if (py !in 0 until frame.height) continue

            var rowMinX = radius + 1
            var rowMaxX = -radius - 1
            for (dx in -radius..radius) {
                val px = centerX + dx
                if (px !in 0 until frame.width) continue
                val color = frame.getPixel(px, py)
                Color.colorToHSV(color, hsv)
                if (hsv[2] <= 0.72f && !isGreenPixel(color)) continue

                totalBright++
                if (dy < -1) topMass++
                if (dy > 1) bottomMass++
                if (dx < -1) leftMass++
                if (dx > 1) rightMass++
                if (dx < rowMinX) rowMinX = dx
                if (dx > rowMaxX) rowMaxX = dx
            }

            if (rowMaxX >= rowMinX) {
                val span = rowMaxX - rowMinX + 1
                if (dy in (-radius * 0.65f).toInt()..(-radius * 0.25f).toInt()) {
                    topSpan = max(topSpan, span)
                }
                if (dy in (radius * 0.25f).toInt()..(radius * 0.65f).toInt()) {
                    bottomSpan = max(bottomSpan, span)
                }
            }
        }

        for (dx in -radius..radius) {
            val px = centerX + dx
            if (px !in 0 until frame.width) continue
            var colMinY = radius + 1
            var colMaxY = -radius - 1
            for (dy in -radius..radius) {
                val py = centerY + dy
                if (py !in 0 until frame.height) continue
                val color = frame.getPixel(px, py)
                Color.colorToHSV(color, hsv)
                if (hsv[2] > 0.72f || isGreenPixel(color)) {
                    if (dy < colMinY) colMinY = dy
                    if (dy > colMaxY) colMaxY = dy
                }
            }
            if (colMaxY >= colMinY) {
                val span = colMaxY - colMinY + 1
                if (dx in (-radius * 0.65f).toInt()..(-radius * 0.25f).toInt()) {
                    leftSpan = max(leftSpan, span)
                }
                if (dx in (radius * 0.25f).toInt()..(radius * 0.65f).toInt()) {
                    rightSpan = max(rightSpan, span)
                }
            }
        }

        if (totalBright < 8) return null

        val scores = listOf(
            ArrowDirection.UP to ((topSpan - bottomSpan) * 1.5f + (topMass - bottomMass)),
            ArrowDirection.DOWN to ((bottomSpan - topSpan) * 1.5f + (bottomMass - topMass)),
            ArrowDirection.LEFT to ((leftSpan - rightSpan) * 1.5f + (leftMass - rightMass)),
            ArrowDirection.RIGHT to ((rightSpan - leftSpan) * 1.5f + (rightMass - leftMass))
        )
        val best = scores.maxByOrNull { it.second }
        return if (best != null && best.second > 2f) best.first else null
    }

    fun getTargetPoint(decision: MinigameDecision, screenWidth: Int, screenHeight: Int): PointF? {
        val norm = when (decision) {
            MinigameDecision.HoldStart, MinigameDecision.HoldRelease -> holdButtonPos
            MinigameDecision.TapNow -> tapButtonPos
            is MinigameDecision.PressArrow -> arrowButtons[decision.direction]
            MinigameDecision.Idle -> null
        } ?: return null

        return PointF(norm.x * screenWidth, norm.y * screenHeight)
    }
}
