package com.example.oilrpai

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var selectedStage = 1
    private lateinit var statusText: TextView

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(this, OilOverlayService::class.java).apply {
                putExtra(OilOverlayService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(OilOverlayService.EXTRA_RESULT_DATA, result.data)
                putExtra(OilOverlayService.EXTRA_STAGE, selectedStage)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            statusText.text = "Status: Vision Service berjalan (Tahap $selectedStage)"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
        }

        val title = TextView(this).apply {
            text = "OilRP AI Clicker"
            textSize = 24f
        }

        statusText = TextView(this).apply {
            text = "Status: Siap"
            setPadding(0, 16, 0, 32)
        }

        val stageGroup = RadioGroup(this).apply {
            val s1 = RadioButton(context).apply { id = 1; text = "Tahap 1: Memompa Minyak"; isChecked = true }
            val s2 = RadioButton(context).apply { id = 2; text = "Tahap 2: Menyuling Minyak" }
            val s3 = RadioButton(context).apply { id = 3; text = "Tahap 3: Mencampur Panah" }
            addView(s1)
            addView(s2)
            addView(s3)
            setOnCheckedChangeListener { _, checkedId -> selectedStage = checkedId }
        }

        val btnAccessibility = Button(this).apply {
            text = "1. Aktifkan Accessibility Service"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val btnStart = Button(this).apply {
            text = "2. Mulai Analisis Layar"
            setOnClickListener {
                if (OilClickerAccessibilityService.instance == null) {
                    statusText.text = "Aktifkan Accessibility Service terlebih dahulu."
                    return@setOnClickListener
                }
                val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projectionLauncher.launch(mgr.createScreenCaptureIntent())
            }
        }

        val btnStop = Button(this).apply {
            text = "Hentikan Service"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OilOverlayService::class.java))
                statusText.text = "Status: Dihentikan"
            }
        }

        root.addView(title)
        root.addView(statusText)
        root.addView(stageGroup)
        root.addView(btnAccessibility)
        root.addView(btnStart)
        root.addView(btnStop)
        setContentView(root)
    }
}
