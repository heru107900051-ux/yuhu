package com.example.oilrpai

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

class OilOverlayService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_STAGE = "stage"
        private const val CHANNEL_ID = "oilrp_clicker_channel"
        private const val NOTIFICATION_ID = 1001
    }

    private val analyzer = OilVisionAnalyzer()
    private val handler = Handler(Looper.getMainLooper())

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var screenWidth = 1080
    private var screenHeight = 2400
    private var activeStage = 1
    private var isHolding = false
    private var lastActionMs = 0L

    private val frameLoop = object : Runnable {
        override fun run() {
            processLatestFrame()
            handler.postDelayed(this, 65L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        activeStage = intent?.getIntExtra(EXTRA_STAGE, 1) ?: 1
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode == Activity.RESULT_OK && resultData != null) {
            startProjection(resultCode, resultData)
        }
        return START_NOT_STICKY
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        val metrics = resources.displayMetrics
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels

        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mgr.getMediaProjection(resultCode, data)

        imageReader = ImageReader.newInstance(
            screenWidth,
            screenHeight,
            PixelFormat.RGBA_8888,
            2
        )

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "OilRPCapture",
            screenWidth,
            screenHeight,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            handler
        )

        handler.removeCallbacks(frameLoop)
        handler.post(frameLoop)
    }

    private fun processLatestFrame() {
        val image = imageReader?.acquireLatestImage() ?: return
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * screenWidth

            val bitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)

            val cropped = Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight)
            bitmap.recycle()

            val decision = when (activeStage) {
                1 -> analyzer.analyzeStage1Pump(cropped, isHolding)
                2 -> analyzer.analyzeStage2Refine(cropped)
                3 -> analyzer.analyzeStage3MixArrows(cropped)
                else -> MinigameDecision.Idle
            }

            dispatchDecision(decision)
            cropped.recycle()
        } finally {
            image.close()
        }
    }

    private fun dispatchDecision(decision: MinigameDecision) {
        val service = OilClickerAccessibilityService.instance ?: return
        val point = analyzer.getTargetPoint(decision, screenWidth, screenHeight) ?: return
        val now = System.currentTimeMillis()
        if (now - lastActionMs < 140L) return

        when (decision) {
            MinigameDecision.HoldStart -> {
                isHolding = true
                lastActionMs = now
                service.holdAt(point, 900L)
            }
            MinigameDecision.HoldRelease -> {
                isHolding = false
                lastActionMs = now
            }
            MinigameDecision.TapNow, is MinigameDecision.PressArrow -> {
                lastActionMs = now
                service.tapAt(point, 60L)
            }
            MinigameDecision.Idle -> Unit
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(frameLoop)
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "OilRP Vision Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("OilRP AI Clicker Aktif")
            .setContentText("Menganalisis layar untuk tahap $activeStage")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }
}
